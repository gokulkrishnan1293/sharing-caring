ER rule pack (outpatient rules). Draft for SME review.

1. Start from the treating provider's final impression or diagnosis. Code only what the provider documented.
2. Uncertain diagnoses are not coded in this setting. If the provider wrote "possible", "probable", "suspected", "rule out" or "ruled out", the condition is not supported; the documented sign or symptom is coded instead.
3. A diagnosis is supported only if it was addressed in this visit: evaluated, tested, treated, or it changed management. A condition that appears only in the history or medication list is not supported.
4. An abnormal lab or imaging result alone is not a diagnosis. The provider must document the condition or its clinical significance.
5. Never judge a lab, imaging or nursing page alone. Read the provider's assessment or final impression page with it.
6. A service is supported only if a report or note shows it was performed in this visit and a documented diagnosis or symptom justifies it.
7. Use the most specific code the documentation supports, and confirm it exists with lookup_code.
8. Visit-level (evaluation and management) codes are out of scope.
