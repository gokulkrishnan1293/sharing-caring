---
id: injury_wound
version: "0.1"
title: Injuries and wound care
description: Lacerations, fractures, sprains and the repair or splinting done for them
applies_to: [S00-S99, T07-T14, CPT 12xxx, CPT 13xxx, CPT 29xxx]
---
Draft for SME review.

Evidence to look for
- The provider documents the injury with its site and side.
- Imaging results when a fracture is coded, as interpreted by the provider or radiologist.
- A procedure note for any repair or splint: site, size or length, and what was done.

How to decide
- The injury code needs the site and side the documentation gives; do not assume a side.
- A repair or splint service needs a procedure note from this visit; a plan to repair is not enough.

Where it usually is
- ED physician note, procedure note, radiology report, final impression.
