---
id: infection_fever
version: "0.1"
title: Fever and infection
description: Fever, suspected or confirmed infection such as pneumonia, urinary infection or sepsis
applies_to: [R50, A41, J18, N39, J06, L03]
---
Draft for SME review.

Evidence to look for
- The provider's final impression: a named infection, or fever alone.
- Test results the provider relies on, such as cultures, urinalysis or chest imaging.
- Treatment: antibiotics given or prescribed, fluids, admission.

How to decide
- "Rule out sepsis" or "possible pneumonia" is not a confirmed infection in this setting; the documented symptom is coded.
- When the provider confirms the source of the fever, the infection is the diagnosis and fever is not reported separately as its symptom.

Where it usually is
- ED physician note, lab results, radiology report, medication administration record, final impression.
