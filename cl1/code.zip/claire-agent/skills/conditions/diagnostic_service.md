---
id: diagnostic_service
version: "0.1"
title: Diagnostic services
description: ECG, X-ray, CT, ultrasound and other tests billed as services
applies_to: [CPT 7xxxx, CPT 93xxx, HCPCS]
---
Draft for SME review.

Evidence to look for
- A report or interpretation for the test from this visit, matching what the code describes (for example the number of views).
- An order or indication for the test.
- A documented diagnosis or symptom that justifies it.

How to decide
- No report or interpretation in the record: not supported.
- Report present but it describes a different test than the code: not supported; say what the record does support.
- Report present and a justifying diagnosis or symptom is documented: supported.

Where it usually is
- Radiology report, ECG report, ED physician note, orders.
