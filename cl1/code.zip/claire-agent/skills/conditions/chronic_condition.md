---
id: chronic_condition
version: "0.1"
title: Chronic condition addressed in the visit
description: Long-term conditions such as diabetes, hypertension, kidney disease or COPD seen during an ER visit
applies_to: [E08, E09, E10, E11, E13, I10, I11, I12, I13, N18, J44, J45, E03, E78]
---
Draft for SME review.

Evidence to look for
- The provider documents the condition in the assessment, ED course or final impression, not only in the history.
- It was addressed in this visit: a test for it, a treatment given, a medication changed or held, or it changed the plan.
- Wording that changes the code, for example a documented complication or "with hyperglycemia".

How to decide
- History or home medication list only: not supported.
- Addressed and documented by the provider: supported, at the specificity the provider's wording supports.

Where it usually is
- History and physical, lab results, medication administration record, ED course, final impression.
