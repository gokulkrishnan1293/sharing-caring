---
id: electrolyte_abnormality
version: "0.1"
title: Electrolyte and fluid abnormalities
description: Low or high potassium, sodium and similar findings, including dehydration
applies_to: [E86, E87]
---
Draft for SME review.

Evidence to look for
- The abnormal value on a lab page.
- The provider names the condition (for example hypokalemia) in the ED course or final impression.
- Treatment or monitoring for it: replacement given, fluids, a repeat level, or a change in plan.

How to decide
- An abnormal value with no provider documentation of the condition is not supported.
- Value plus provider documentation plus treatment or monitoring: supported.

Where it usually is
- Lab results, medication administration record, ED course, final impression.
