---
id: chest_pain_acs
version: "0.1"
title: Chest pain and acute coronary syndrome
description: Chest pain presentations, including suspected or confirmed heart attack and unstable angina
applies_to: [I20, I21, I24, R07]
---
Draft for SME review.

Evidence to look for
- The provider's final impression: does it name a cardiac diagnosis, or only chest pain?
- ECG interpretation and troponin results, and whether the provider calls them positive or negative.
- Treatment and disposition: cardiology consult, catheterization, admission or transfer, or discharge home.

How to decide
- A heart attack or unstable angina code needs the provider to state that diagnosis as confirmed.
- If the workup was to rule it out and the provider's impression is chest pain, the cardiac code is not supported and the chest pain symptom code is the reportable diagnosis.
- Choose the chest pain code that matches the provider's wording; use lookup_code to see the options.

Where it usually is
- ED physician note, ED course or reassessment, final impression, lab results, ECG report.
