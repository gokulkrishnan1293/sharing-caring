# CLAIRE ER coding agent

An agent that reads an emergency department record, checks every code on the claim against the record, and finds reportable diagnoses and services that the claim missed. Each finding cites the pages and quotes it relies on. Coder corrections are saved as memory and shown to the agent on similar cases.

Scope of this version: ER only; ICD-10-CM diagnoses and CPT/HCPCS services. Visit-level (E/M) codes are skipped.

## The four memory layers

| Layer | Holds | Written by | Where |
|---|---|---|---|
| Working | Pages, page index cards (page map), case summary, findings, evidence ledger, trace | The agent, per case | `cases`, `case_pages`, `findings`, `evidence`, `trace_events` |
| Semantic | Reference codes and code-pair edits | You, by loading CSVs | `medical_codes`, `code_pair_edits` |
| Procedural | Ontology, ER rule pack, condition skills | You, in dev; read-only at runtime | `skills/` files; `skills` table counts drift flags only |
| Episodic | Coder corrections, structured, no chart text | Coder review, immediately | `episodes` |

## How a case runs

1. Ingest: pages with their text and an index card each (output of your existing page-conversion prompt, plus the card).
2. Case summary: one text-only call over the cards. It is the only record content always in the agent's context.
3. Verify: for each claim code, a bounded loop. The agent loads one skill, finds pages through the page map and text search, reads only those pages, looks up the code, and gives a verdict. Past corrections for that code family and payer are pre-loaded.
4. Checks in code: every quote must appear on the page it cites, the evidence must meet the ontology rules, and the code must exist in the reference set. Failing checks send a finding to `needs_review`.
5. Discover: compares what the cards list with what was handled, proposes leads, and runs each through the same loop. Unsupported leads are dropped.
6. Finalize: flags code-pair conflicts among reportable codes and sets the case to awaiting review.

Buckets: `confirmed`, `unsupported`, `missed`, `needs_review`.

Coder review: accepting closes a finding. Rejecting or correcting it needs a reason and saves an episode at once. A root cause of `skill_gap` adds a drift flag to that skill version; `GET /skills/flagged` lists skills at the threshold for fixing in dev.

## Run it

```bash
docker compose up -d                       # Postgres 16 on localhost:5432
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env && export $(grep -v '^#' .env | xargs)

python -m claire_agent.demo data/sample    # full run on a synthetic case with a scripted model, no API key needed
TEST_DATABASE_URL=postgresql://claire:claire@localhost:5432/claire pytest   # wipes that database
```

The demo's model replies are scripted. It proves the pipeline, memory reads and checks work. It says nothing about accuracy on real records.

To use a real model:

```bash
pip install -e ".[llm]" langchain-aws      # or langchain-openai, langchain-anthropic
export CLAIRE_MODEL="bedrock_converse:<model id>"
uvicorn claire_agent.api:app_from_env --factory --reload
```

## API

| Method and path | Purpose |
|---|---|
| `POST /cases` | Ingest a case (see `data/sample/er_case.json` for the shape) |
| `POST /cases/{id}/run` | Run the agent |
| `GET /cases/{id}/findings` | Findings with evidence |
| `GET /cases/{id}/trace` | Every step, tool call and memory read, with tokens |
| `GET /cases/{id}/stats` | Pages opened, peak context, tokens, cost |
| `POST /findings/{id}/review` | Accept, reject or correct |
| `POST /cases/{id}/missed-codes` | Coder adds a code the agent missed |
| `DELETE /cases/{id}` | Purge working memory for a closed case |
| `GET /episodes`, `GET /precedents` | Episodic memory |
| `GET /skills`, `GET /skills/flagged` | Skills and drift flags |
| `GET /stats` | Dashboard numbers across cases |

## Before real use

- Load your company's code tables and edit tables with `python -m claire_agent.seed <folder>` (CSV columns are in `data/sample`). The sample codes and descriptions are placeholders.
- The skills, ontology and ER rule pack are drafts. Have an SME review them.
- Build the eval set from coder-confirmed ER records and compare against your current flow.
- The note filter on episodes catches obvious identifiers only. It is not de-identification; get compliance sign-off before copying episodes between environments.
- Set `CLAIRE_RATE_INPUT` and `CLAIRE_RATE_OUTPUT` to your model's prices. Token counts use the provider's numbers when it returns them and an estimate otherwise.
- Not built yet: the alias cache, auto-trusted patterns, E/M scoring, inpatient rules.
