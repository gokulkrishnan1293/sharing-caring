"""Working memory: one case's pages, page map, case summary, findings and evidence ledger."""
from __future__ import annotations

import re
from typing import Any

from psycopg.types.json import Jsonb

from ..db import Database
from ..models import CaseIn

CARD_FIELDS = ("problems", "medications", "procedures", "abnormal_values")


def create_case(db: Database, case: CaseIn) -> None:
    with db.transaction() as conn:
        conn.execute(
            "INSERT INTO cases (case_id, setting, payer, claim_codes) VALUES (%s, %s, %s, %s)",
            (case.case_id, case.setting, case.payer, Jsonb([c.model_dump() for c in case.claim_codes])),
        )
        for page in case.pages:
            conn.execute(
                "INSERT INTO case_pages (case_id, page_num, page_text, card) VALUES (%s, %s, %s, %s)",
                (case.case_id, page.page_num, page.text, Jsonb(page.card.model_dump())),
            )


def get_case(db: Database, case_id: str) -> dict | None:
    return db.one("SELECT * FROM cases WHERE case_id = %s", (case_id,))


def list_cases(db: Database) -> list[dict]:
    return db.all(
        "SELECT c.case_id, c.setting, c.payer, c.status, c.created_at, "
        "(SELECT count(*) FROM case_pages p WHERE p.case_id = c.case_id) AS pages "
        "FROM cases c ORDER BY c.created_at DESC"
    )


def set_summary(db: Database, case_id: str, summary: str) -> None:
    db.execute("UPDATE cases SET case_summary = %s WHERE case_id = %s", (summary, case_id))


def set_status(db: Database, case_id: str, status: str) -> None:
    db.execute("UPDATE cases SET status = %s WHERE case_id = %s", (status, case_id))


def purge_case(db: Database, case_id: str) -> None:
    """Clear working memory for a closed case. Episodes are kept; they hold no chart text."""
    db.execute("DELETE FROM cases WHERE case_id = %s", (case_id,))


def get_cards(db: Database, case_id: str) -> list[dict]:
    """The page map: one index card per page."""
    rows = db.all("SELECT page_num, card FROM case_pages WHERE case_id = %s ORDER BY page_num", (case_id,))
    return [{"page": r["page_num"], **r["card"]} for r in rows]


def get_page(db: Database, case_id: str, page_num: int) -> dict | None:
    return db.one(
        "SELECT page_num, page_text, card FROM case_pages WHERE case_id = %s AND page_num = %s",
        (case_id, page_num),
    )


def get_pages_text(db: Database, case_id: str) -> dict[int, str]:
    rows = db.all("SELECT page_num, page_text FROM case_pages WHERE case_id = %s ORDER BY page_num", (case_id,))
    return {r["page_num"]: r["page_text"] for r in rows}


def find_pages(cards: list[dict], term: str, page_type: str | None = None, limit: int = 20) -> list[dict]:
    """Query the page map. Matches a term against what each card lists, optionally filtered by page type."""
    needle = term.strip().lower()
    out = []
    for card in cards:
        if page_type and page_type.lower() not in card.get("page_type", "").lower():
            continue
        matched = [f for f in CARD_FIELDS if any(needle in item.lower() for item in card.get(f, []))]
        if needle and needle in card.get("page_type", "").lower():
            matched.append("page_type")
        if matched or (page_type and not needle):
            out.append({"page": card["page"], "page_type": card.get("page_type"), "matched_in": matched,
                        "quality": card.get("quality", "clean")})
    return out[:limit]


def search_text(pages: dict[int, str], query: str, limit: int = 10, width: int = 80) -> list[dict]:
    """Full-text search across the record, so a weak page card never hides a page. Terms may be joined with OR."""
    terms = [t.strip().lower() for t in re.split(r"\s+OR\s+", query) if t.strip()]
    out = []
    for num, text in pages.items():
        lower = text.lower()
        for term in terms:
            pos = lower.find(term)
            if pos >= 0:
                start, end = max(0, pos - width), min(len(text), pos + len(term) + width)
                out.append({"page": num, "term": term, "snippet": text[start:end].replace("\n", " ")})
                break
    return out[:limit]


def clear_run(db: Database, case_id: str) -> None:
    """Remove the previous run's findings and trace before a rerun."""
    db.execute("DELETE FROM findings WHERE case_id = %s", (case_id,))
    db.execute("DELETE FROM trace_events WHERE case_id = %s", (case_id,))


def save_finding(db: Database, case_id: str, finding: dict[str, Any], evidence: list[dict]) -> int:
    with db.transaction() as conn:
        row = conn.execute(
            "INSERT INTO findings (case_id, code, code_system, description, kind, source, bucket, rationale, "
            "skill_id, skill_version, precedent_ids, pages_read, flags, review_status) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING finding_id",
            (case_id, finding["code"], finding["code_system"], finding.get("description"), finding["kind"],
             finding["source"], finding["bucket"], finding.get("rationale"), finding.get("skill_id"),
             finding.get("skill_version"), Jsonb(finding.get("precedent_ids", [])),
             Jsonb(finding.get("pages_read", [])), Jsonb(finding.get("flags", [])),
             finding.get("review_status", "pending")),
        ).fetchone()
        for ev in evidence:
            conn.execute(
                "INSERT INTO evidence (finding_id, page_num, quote, supports, verified) VALUES (%s,%s,%s,%s,%s)",
                (row["finding_id"], ev["page"], ev["quote"], ev["supports"], ev["verified"]),
            )
    return row["finding_id"]


def add_flag(db: Database, finding_id: int, flag: dict) -> None:
    db.execute("UPDATE findings SET flags = flags || %s WHERE finding_id = %s", (Jsonb([flag]), finding_id))


def get_finding(db: Database, finding_id: int) -> dict | None:
    return db.one("SELECT * FROM findings WHERE finding_id = %s", (finding_id,))


def list_findings(db: Database, case_id: str) -> list[dict]:
    findings = db.all("SELECT * FROM findings WHERE case_id = %s ORDER BY finding_id", (case_id,))
    ev = db.all(
        "SELECT e.* FROM evidence e JOIN findings f USING (finding_id) WHERE f.case_id = %s ORDER BY e.evidence_id",
        (case_id,),
    )
    by_finding: dict[int, list[dict]] = {}
    for e in ev:
        by_finding.setdefault(e["finding_id"], []).append(
            {"page": e["page_num"], "quote": e["quote"], "supports": e["supports"], "verified": e["verified"]})
    for f in findings:
        f["evidence"] = by_finding.get(f["finding_id"], [])
    return findings


def set_review_status(db: Database, finding_id: int, status: str) -> None:
    db.execute("UPDATE findings SET review_status = %s WHERE finding_id = %s", (status, finding_id))


def pending_count(db: Database, case_id: str) -> int:
    return db.one("SELECT count(*) AS n FROM findings WHERE case_id = %s AND review_status = 'pending'",
                  (case_id,))["n"]
