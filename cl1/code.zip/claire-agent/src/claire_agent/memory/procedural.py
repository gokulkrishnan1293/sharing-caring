"""Procedural memory: ontology, setting rule packs and condition skills.

Skill text lives in versioned files and is read-only at runtime. The database only tracks drift flags.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml

from ..db import Database


@dataclass(frozen=True)
class Skill:
    skill_id: str
    version: str
    title: str
    description: str
    applies_to: tuple[str, ...]
    body: str


def _split_frontmatter(text: str) -> tuple[dict, str]:
    if not text.startswith("---"):
        raise ValueError("skill file must start with YAML frontmatter")
    _, front, body = text.split("---", 2)
    return yaml.safe_load(front) or {}, body.strip()


class SkillRegistry:
    def __init__(self, skills: dict[str, Skill], rule_packs: dict[str, str], ontology: dict):
        self.skills = skills
        self.rule_packs = rule_packs
        self.ontology = ontology

    @classmethod
    def load(cls, root: Path) -> "SkillRegistry":
        root = Path(root)
        skills: dict[str, Skill] = {}
        for path in sorted((root / "conditions").glob("*.md")):
            meta, body = _split_frontmatter(path.read_text())
            skill = Skill(
                skill_id=meta["id"], version=str(meta["version"]), title=meta["title"],
                description=meta["description"], applies_to=tuple(meta.get("applies_to", [])), body=body,
            )
            skills[skill.skill_id] = skill
        packs = {p.stem.upper(): p.read_text().strip() for p in sorted((root / "rule_packs").glob("*.md"))}
        ontology = yaml.safe_load((root / "ontology.yaml").read_text())
        return cls(skills, packs, ontology)

    def index(self) -> str:
        """One line per skill. This is all the agent sees until it loads one."""
        return "\n".join(
            f"- {s.skill_id}: {s.description} (applies to: {', '.join(s.applies_to) or 'any'})"
            for s in self.skills.values()
        )

    def get(self, skill_id: str) -> Skill | None:
        return self.skills.get(skill_id)

    def rule_pack(self, setting: str) -> str:
        return self.rule_packs[setting.upper()]

    def requirements(self, kind: str) -> dict:
        return self.ontology["value_types"][kind]


def sync_registry(db: Database, registry: SkillRegistry) -> None:
    """Register every loaded skill version. Existing rows keep their drift counts."""
    for s in registry.skills.values():
        db.execute(
            "INSERT INTO skills (skill_id, version, title) VALUES (%s, %s, %s) "
            "ON CONFLICT (skill_id, version) DO UPDATE SET title = EXCLUDED.title, loaded_at = now()",
            (s.skill_id, s.version, s.title),
        )


def flag_drift(db: Database, skill_id: str, version: str, episode_id: int) -> int:
    """Count a correction against a skill version. The skill text itself is never changed here."""
    row = db.one(
        "INSERT INTO skills (skill_id, version, title, drift_flag_count, last_drift_episode_id) "
        "VALUES (%s, %s, %s, 1, %s) ON CONFLICT (skill_id, version) DO UPDATE "
        "SET drift_flag_count = skills.drift_flag_count + 1, last_drift_episode_id = EXCLUDED.last_drift_episode_id "
        "RETURNING drift_flag_count",
        (skill_id, version, skill_id, episode_id),
    )
    return row["drift_flag_count"]


def flagged_skills(db: Database, min_flags: int) -> list[dict]:
    return db.all(
        "SELECT skill_id, version, title, drift_flag_count, last_drift_episode_id FROM skills "
        "WHERE drift_flag_count >= %s ORDER BY drift_flag_count DESC, skill_id",
        (min_flags,),
    )
