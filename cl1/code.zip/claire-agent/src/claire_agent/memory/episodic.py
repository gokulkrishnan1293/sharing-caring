"""Episodic memory: coder corrections, saved at once and retrieved by setting, payer and code family."""
from __future__ import annotations

import hashlib
import re

from ..db import Database

REASON_TEXT = {
    "insufficient_documentation": "the documentation did not support the code",
    "history_only": "the condition was only in the history and was not addressed in the visit",
    "uncertain_diagnosis": "the diagnosis was uncertain or ruled out, so the symptom is coded instead",
    "wrong_specificity": "the record supports a different level of specificity",
    "payer_rule": "a payer rule applies",
    "not_clinically_valid": "the code was not clinically valid for this record",
    "missed_by_agent": "the agent did not find it",
    "other": "another reason",
}

_PHI_PATTERNS = [
    (r"\b\d{6,}\b", "a long number"),
    (r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b", "a date"),
    (r"\b\d{4}-\d{2}-\d{2}\b", "a date"),
    (r"[\w.+-]+@[\w-]+\.[\w.]+", "an email address"),
    (r"\b(?:mrn|dob|ssn)\b", "an identifier label"),
]


def phi_tripwire(note: str | None) -> None:
    """Reject coder notes that look like they carry identifiers.

    This is a tripwire, not de-identification: it catches obvious slips only.
    """
    if not note:
        return
    for pattern, label in _PHI_PATTERNS:
        if re.search(pattern, note, flags=re.IGNORECASE):
            raise ValueError(f"note looks like it contains {label}; episodes must not hold patient details")


def code_family(code: str, code_system: str) -> str:
    """ICD-10-CM codes group by their three-character category; service codes stand alone."""
    code = code.strip().upper()
    return code.split(".")[0][:3] if code_system == "ICD-10-CM" else code


def case_hash(case_id: str) -> str:
    return hashlib.sha256(case_id.encode()).hexdigest()[:16]


def save_episode(db: Database, *, setting: str, payer: str, code: str, code_system: str, decision: str,
                 reason: str, coder_id: str, case_id: str, agent_bucket: str | None = None,
                 corrected_code: str | None = None, root_cause: str = "none", note: str | None = None,
                 skill_id: str | None = None, skill_version: str | None = None) -> int:
    phi_tripwire(note)
    row = db.one(
        "INSERT INTO episodes (setting, payer, code, code_system, code_family, agent_bucket, decision, "
        "corrected_code, reason, root_cause, note, skill_id, skill_version, coder_id, case_hash) "
        "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING episode_id",
        (setting, payer, code.upper(), code_system, code_family(code, code_system), agent_bucket, decision,
         corrected_code.upper() if corrected_code else None, reason, root_cause, note, skill_id, skill_version,
         coder_id, case_hash(case_id)),
    )
    return row["episode_id"]


def _describe(row: dict) -> str:
    why = REASON_TEXT.get(row["reason"], row["reason"])
    if row["decision"] == "rejected":
        head = f"Coders rejected {row['code']}"
    elif row["decision"] == "corrected":
        head = f"Coders changed {row['code']} to {row['corrected_code']}"
    else:
        head = f"Coders added {row['code']}, which the agent had missed"
    text = f"{head} in {row['cases']} past case(s), {row['coders']} coder(s): {why}."
    if row["notes"]:
        text += " Coder notes: " + " | ".join(row["notes"][:2])
    return text


def precedents(db: Database, setting: str, payer: str, family: str, limit: int = 3) -> list[dict]:
    """Past corrections for this code family and payer, grouped into patterns and ranked by how often they recur."""
    rows = db.all(
        "SELECT decision, reason, code, corrected_code, count(DISTINCT case_hash) AS cases, "
        "count(DISTINCT coder_id) AS coders, max(created_at) AS latest, "
        "array_agg(episode_id ORDER BY created_at DESC) AS ids, "
        "array_remove(array_agg(note ORDER BY created_at DESC), NULL) AS notes "
        "FROM episodes WHERE setting = %s AND payer = %s AND code_family = %s "
        "GROUP BY decision, reason, code, corrected_code ORDER BY cases DESC, latest DESC LIMIT %s",
        (setting, payer, family, limit),
    )
    return [{"episode_ids": r["ids"], "cases": r["cases"], "coders": r["coders"], "decision": r["decision"],
             "reason": r["reason"], "text": _describe(r)} for r in rows]


def list_episodes(db: Database, limit: int = 100) -> list[dict]:
    return db.all("SELECT * FROM episodes ORDER BY episode_id DESC LIMIT %s", (limit,))
