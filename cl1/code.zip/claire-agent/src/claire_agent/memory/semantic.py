"""Semantic memory: the reference code sets and code-pair edits. Read-only to the agent."""
from __future__ import annotations

import csv
import re
from pathlib import Path

from ..db import Database


def get_code(db: Database, code: str, code_system: str | None = None) -> dict | None:
    code = code.strip().upper()
    if code_system:
        return db.one("SELECT code, code_system, description FROM medical_codes WHERE code = %s AND code_system = %s",
                      (code, code_system))
    return db.one("SELECT code, code_system, description FROM medical_codes WHERE code = %s", (code,))


def lookup_code(db: Database, query: str, limit: int = 5) -> list[dict]:
    """Exact code match first, then full-text search on descriptions (all words, then any word)."""
    exact = get_code(db, query)
    if exact:
        return [exact]
    sql = ("SELECT code, code_system, description FROM medical_codes WHERE search @@ {q} "
           "ORDER BY ts_rank(search, {q}) DESC, code LIMIT %s")
    rows = db.all(sql.format(q="plainto_tsquery('english', %s)"), (query, query, limit))
    if rows:
        return rows
    words = re.findall(r"[A-Za-z0-9]+", query)
    if not words:
        return []
    any_word = " | ".join(words)
    return db.all(sql.format(q="to_tsquery('english', %s)"), (any_word, any_word, limit))


def pair_conflicts(db: Database, codes: list[str]) -> list[dict]:
    """Code pairs in this set that an edit says cannot be reported together."""
    if len(codes) < 2:
        return []
    return db.all(
        "SELECT code_a, code_b, kind, note FROM code_pair_edits WHERE code_a = ANY(%s) AND code_b = ANY(%s)",
        (codes, codes),
    )


def load_codes_csv(db: Database, path: Path) -> int:
    n = 0
    with path.open(newline="") as fh, db.transaction() as conn:
        for row in csv.DictReader(fh):
            conn.execute(
                "INSERT INTO medical_codes (code, code_system, description) VALUES (%s, %s, %s) "
                "ON CONFLICT (code_system, code) DO UPDATE SET description = EXCLUDED.description",
                (row["code"].strip().upper(), row["code_system"].strip(), row["description"].strip()),
            )
            n += 1
    return n


def load_pair_edits_csv(db: Database, path: Path) -> int:
    n = 0
    with path.open(newline="") as fh, db.transaction() as conn:
        for row in csv.DictReader(fh):
            a, b = row["code_a"].strip().upper(), row["code_b"].strip().upper()
            for x, y in ((a, b), (b, a)):
                conn.execute(
                    "INSERT INTO code_pair_edits (code_a, code_b, kind, note) VALUES (%s, %s, %s, %s) "
                    "ON CONFLICT (code_a, code_b) DO UPDATE SET kind = EXCLUDED.kind, note = EXCLUDED.note",
                    (x, y, row["kind"].strip(), row.get("note", "").strip()),
                )
            n += 1
    return n
