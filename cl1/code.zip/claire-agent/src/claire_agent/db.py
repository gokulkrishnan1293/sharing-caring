from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

import psycopg
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

SQL_DIR = Path(__file__).parent / "sql"


class Database:
    """Thin wrapper over a psycopg connection pool; rows come back as dicts."""

    def __init__(self, url: str, max_size: int = 5):
        self.pool = ConnectionPool(
            url, min_size=1, max_size=max_size, open=True,
            kwargs={"row_factory": dict_row, "autocommit": True},
        )

    def execute(self, sql: str, params: Any = None) -> None:
        with self.pool.connection() as conn:
            conn.execute(sql, params)

    def one(self, sql: str, params: Any = None) -> dict | None:
        with self.pool.connection() as conn:
            return conn.execute(sql, params).fetchone()

    def all(self, sql: str, params: Any = None) -> list[dict]:
        with self.pool.connection() as conn:
            return conn.execute(sql, params).fetchall()

    @contextmanager
    def transaction(self) -> Iterator[psycopg.Connection]:
        with self.pool.connection() as conn:
            with conn.transaction():
                yield conn

    def migrate(self) -> None:
        for path in sorted(SQL_DIR.glob("*.sql")):
            self.execute(path.read_text())

    def close(self) -> None:
        self.pool.close()
