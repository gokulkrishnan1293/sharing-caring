from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

SupportKind = Literal[
    "provider_statement", "evaluated", "tested", "treated", "management",
    "performed", "supporting_diagnosis", "other",
]
Reason = Literal[
    "insufficient_documentation", "history_only", "uncertain_diagnosis", "wrong_specificity",
    "payer_rule", "not_clinically_valid", "missed_by_agent", "other",
]
RootCause = Literal["page_map_miss", "skill_gap", "code_mismatch", "agent_reasoning", "none"]


class PageCard(BaseModel):
    """Index card written by the page-conversion step: what a page mentions, not what matters."""

    page_type: str
    date: str | None = None
    problems: list[str] = Field(default_factory=list)
    medications: list[str] = Field(default_factory=list)
    procedures: list[str] = Field(default_factory=list)
    abnormal_values: list[str] = Field(default_factory=list)
    quality: Literal["clean", "low_confidence", "low_value"] = "clean"


class PageIn(BaseModel):
    page_num: int = Field(ge=1)
    text: str
    card: PageCard


class ClaimCode(BaseModel):
    code: str
    code_system: Literal["ICD-10-CM", "CPT", "HCPCS"]


class CaseIn(BaseModel):
    case_id: str
    payer: str
    setting: Literal["ER"] = "ER"
    claim_codes: list[ClaimCode] = Field(default_factory=list)
    pages: list[PageIn]


class EvidenceIn(BaseModel):
    page: int
    quote: str
    supports: SupportKind = "other"


class ReviewIn(BaseModel):
    decision: Literal["accept", "reject", "correct"]
    coder_id: str
    reason: Reason | None = None
    root_cause: RootCause = "none"
    corrected_code: str | None = None
    corrected_code_system: Literal["ICD-10-CM", "CPT", "HCPCS"] | None = None
    note: str | None = Field(default=None, max_length=300)


class MissedCodeIn(BaseModel):
    code: str
    code_system: Literal["ICD-10-CM", "CPT", "HCPCS"]
    coder_id: str
    reason: Reason = "missed_by_agent"
    root_cause: RootCause = "none"
    note: str | None = Field(default=None, max_length=300)


def kind_of(code_system: str) -> str:
    return "diagnosis" if code_system == "ICD-10-CM" else "service"


def is_em_code(code: str, code_system: str) -> bool:
    """Evaluation and management visit codes, which this version does not score."""
    return code_system == "CPT" and code.isdigit() and 99202 <= int(code) <= 99499
