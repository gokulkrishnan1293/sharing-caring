"""Trace events: every node visit, model call, tool call and memory read, with tokens. The console reads these."""
from __future__ import annotations

from psycopg.types.json import Jsonb

from .config import Settings
from .db import Database


class Tracer:
    def __init__(self, db: Database, case_id: str, run_id: str):
        self.db, self.case_id, self.run_id, self.seq = db, case_id, run_id, 0

    def emit(self, node: str, kind: str, candidate: str | None = None, detail: dict | None = None,
             input_tokens: int = 0, output_tokens: int = 0, context_tokens: int | None = None) -> None:
        self.seq += 1
        self.db.execute(
            "INSERT INTO trace_events (case_id, run_id, seq, node, kind, candidate, detail, input_tokens, "
            "output_tokens, context_tokens) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (self.case_id, self.run_id, self.seq, node, kind, candidate, Jsonb(detail or {}),
             input_tokens, output_tokens, context_tokens),
        )


def get_trace(db: Database, case_id: str) -> list[dict]:
    return db.all(
        "SELECT seq, node, kind, candidate, detail, input_tokens, output_tokens, context_tokens, created_at "
        "FROM trace_events WHERE case_id = %s ORDER BY seq", (case_id,))


def _cost(settings: Settings, tokens_in: int, tokens_out: int) -> float:
    return round((tokens_in * settings.rate_input_per_mtok + tokens_out * settings.rate_output_per_mtok) / 1e6, 4)


def case_stats(db: Database, settings: Settings, case_id: str) -> dict:
    """Tokens, cost and context for the agent's reasoning on one case. Page conversion is billed elsewhere."""
    t = db.one(
        "SELECT coalesce(sum(input_tokens),0) AS input_tokens, coalesce(sum(output_tokens),0) AS output_tokens, "
        "count(*) FILTER (WHERE kind = 'llm') AS model_calls, "
        "count(*) FILTER (WHERE kind IN ('tool','memory') AND detail ? 'tool') AS tool_calls, "
        "coalesce(max(context_tokens),0) AS peak_context_tokens "
        "FROM trace_events WHERE case_id = %s", (case_id,))
    p = db.one(
        "SELECT count(*) AS pages, coalesce(sum(length(page_text)),0) AS chars FROM case_pages WHERE case_id = %s",
        (case_id,))
    opened = db.one(
        "SELECT count(DISTINCT detail->'args'->>'page_num') AS n FROM trace_events "
        "WHERE case_id = %s AND detail->>'tool' = 'read_page'", (case_id,))["n"]
    buckets = {r["bucket"]: r["n"] for r in db.all(
        "SELECT bucket, count(*) AS n FROM findings WHERE case_id = %s GROUP BY bucket", (case_id,))}
    record_tokens = (p["chars"] + 3) // 4
    peak = t["peak_context_tokens"]
    return {
        "case_id": case_id,
        "pages": p["pages"],
        "pages_opened": opened,
        "record_tokens_estimate": record_tokens,
        "peak_context_tokens": peak,
        "peak_context_share_of_record": round(peak / record_tokens, 3) if record_tokens else None,
        "input_tokens": t["input_tokens"],
        "output_tokens": t["output_tokens"],
        "model_calls": t["model_calls"],
        "tool_calls": t["tool_calls"],
        "reasoning_cost": _cost(settings, t["input_tokens"], t["output_tokens"]),
        "findings": buckets,
    }


def overall_stats(db: Database, settings: Settings) -> dict:
    cases = [r["case_id"] for r in db.all("SELECT case_id FROM cases ORDER BY created_at")]
    per_case = [case_stats(db, settings, c) for c in cases]
    totals: dict[str, int] = {}
    for s in per_case:
        for bucket, n in s["findings"].items():
            totals[bucket] = totals.get(bucket, 0) + n
    episodes = db.one("SELECT count(*) AS n FROM episodes")["n"]
    return {
        "cases": len(per_case),
        "pages": sum(s["pages"] for s in per_case),
        "reasoning_cost": round(sum(s["reasoning_cost"] for s in per_case), 4),
        "findings": totals,
        "episodes": episodes,
        "per_case": per_case,
    }
