"""Run the synthetic ER sample end to end with a scripted model, so no provider or key is needed.

Usage: python -m claire_agent.demo [path to data/sample]

The scripted replies stand in for a real model. They show the pipeline, the memory reads and the checks
working; they say nothing about how accurate a real model will be on real records.
"""
from __future__ import annotations

import json
import re
import sys
import uuid
from pathlib import Path
from typing import Sequence

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage

from . import prompts
from .agent.graph import Deps, run_case
from .config import Settings
from .db import Database
from .llm import text_of
from .memory import episodic, procedural, working
from .memory.procedural import SkillRegistry
from .models import CaseIn
from .seed import seed
from .testing import ScriptedChatModel
from .trace import case_stats

SAMPLE_SUMMARY = (
    "Adult seen in the emergency department for chest pain of 2 hours (p.2-4). ECG (p.5), serial troponin (p.6) "
    "and chest X-ray (p.7) were done; acute coronary syndrome was ruled out (p.10). Low potassium was treated with "
    "oral potassium and high glucose with insulin (p.6, 8, 10). History of type 2 diabetes and hypertension (p.3). "
    "Final impression lists chest pain, hypokalemia and type 2 diabetes with hyperglycemia; discharged home (p.11)."
)


def call(name: str, **args) -> dict:
    return {"name": name, "args": args, "id": f"call_{uuid.uuid4().hex[:8]}", "type": "tool_call"}


def ai(*calls: dict) -> AIMessage:
    return AIMessage(content="", tool_calls=list(calls))


def ev(page: int, quote: str, supports: str) -> dict:
    return {"page": page, "quote": quote, "supports": supports}


SCRIPTS: dict[str, list[AIMessage]] = {
    "I21.4": [
        ai(call("load_skill", skill_id="chest_pain_acs")),
        ai(call("find_pages", term="troponin"), call("search_text", query="acute coronary OR myocardial infarction")),
        ai(call("read_page", page_num=6), call("read_page", page_num=10), call("read_page", page_num=11)),
        ai(call("lookup_code", query="I21.4")),
        ai(call("submit_verdict", supported=False, code="I21.4", code_system="ICD-10-CM",
                rationale="Troponin was negative twice and the provider documents acute coronary syndrome as ruled "
                          "out. The final impression is chest pain, so the heart attack code is not supported.",
                evidence=[ev(6, "Troponin I at 3 hours: less than 0.01 ng/mL (negative)", "tested"),
                          ev(10, "acute coronary syndrome ruled out", "other"),
                          ev(11, "Chest pain, unspecified", "provider_statement")])),
    ],
    "E11.65": [
        ai(call("load_skill", skill_id="chronic_condition")),
        ai(call("find_pages", term="diabetes"), call("find_pages", term="insulin")),
        ai(call("read_page", page_num=6), call("read_page", page_num=8), call("read_page", page_num=11)),
        ai(call("lookup_code", query="E11.65")),
        ai(call("submit_verdict", supported=True, code="E11.65", code_system="ICD-10-CM",
                rationale="The provider documents type 2 diabetes with hyperglycemia, glucose was tested and "
                          "insulin was given in this visit.",
                evidence=[ev(11, "Type 2 diabetes mellitus with hyperglycemia", "provider_statement"),
                          ev(6, "Glucose 268 mg/dL (high)", "tested"),
                          ev(8, "Insulin lispro 6 units subcutaneous", "treated")])),
    ],
    "93010": [
        ai(call("load_skill", skill_id="diagnostic_service")),
        ai(call("find_pages", term="ECG")),
        ai(call("read_page", page_num=5), call("read_page", page_num=11)),
        ai(call("lookup_code", query="93010")),
        ai(call("submit_verdict", supported=True, code="93010", code_system="CPT",
                rationale="An ECG interpretation and report from this visit is in the record, done for chest pain.",
                evidence=[ev(5, "12-lead ECG interpretation and report", "performed"),
                          ev(11, "Chest pain, unspecified", "supporting_diagnosis")])),
    ],
    "71046": [
        ai(call("load_skill", skill_id="diagnostic_service")),
        ai(call("find_pages", term="chest x-ray")),
        ai(call("read_page", page_num=7)),
        ai(call("lookup_code", query="71046")),
        ai(call("submit_verdict", supported=True, code="71046", code_system="CPT",
                rationale="The radiology report shows a 2-view chest X-ray done for chest pain.",
                evidence=[ev(7, "Chest X-ray, 2 views", "performed"),
                          ev(7, "Indication: chest pain", "supporting_diagnosis")])),
    ],
    "chest pain": [
        ai(call("load_skill", skill_id="chest_pain_acs")),
        ai(call("read_page", page_num=2), call("read_page", page_num=5), call("read_page", page_num=11)),
        ai(call("lookup_code", query="chest pain unspecified")),
        ai(call("get_precedents", code="R07.9", code_system="ICD-10-CM")),
        ai(call("submit_verdict", supported=True, code="R07.9", code_system="ICD-10-CM",
                rationale="Chest pain is the provider's final impression and was worked up in this visit; the "
                          "cardiac cause was ruled out, so the symptom is the reportable diagnosis.",
                evidence=[ev(11, "Chest pain, unspecified", "provider_statement"),
                          ev(2, "Chief complaint: chest pain for 2 hours", "evaluated"),
                          ev(5, "No acute ischemic changes", "tested")])),
    ],
    "hypokalemia": [
        ai(call("load_skill", skill_id="electrolyte_abnormality")),
        ai(call("read_page", page_num=6), call("read_page", page_num=8), call("read_page", page_num=10)),
        ai(call("lookup_code", query="hypokalemia")),
        ai(call("submit_verdict", supported=True, code="E87.6", code_system="ICD-10-CM",
                rationale="Low potassium on the lab page, named by the provider and treated with oral potassium.",
                evidence=[ev(10, "Hypokalemia repleted with oral potassium chloride", "provider_statement"),
                          ev(6, "Potassium 3.1 mmol/L (low)", "tested"),
                          ev(8, "Potassium chloride 40 mEq by mouth", "treated")])),
    ],
    "hypertension": [
        ai(call("load_skill", skill_id="chronic_condition")),
        ai(call("search_text", query="hypertension OR lisinopril")),
        ai(call("read_page", page_num=3), call("read_page", page_num=11)),
        ai(call("submit_verdict", supported=False, code="I10", code_system="ICD-10-CM",
                rationale="Hypertension appears only in the past history and home medication list. It was not "
                          "assessed or treated in this visit and is not in the final impression.",
                evidence=[ev(3, "Past medical history: type 2 diabetes mellitus, hypertension", "other")])),
    ],
}

SAMPLE_LEADS = [
    {"term": "chest pain", "kind": "diagnosis", "pages": [2, 3, 11],
     "why": "Final impression lists chest pain and no chest pain code has been handled."},
    {"term": "hypokalemia", "kind": "diagnosis", "pages": [6, 8, 10, 11],
     "why": "Potassium chloride was given and no handled code explains it."},
    {"term": "hypertension", "kind": "diagnosis", "pages": [3], "why": "Listed in the history with a home medication."},
]


def sample_responder(messages: Sequence[BaseMessage]) -> AIMessage:
    """Scripted replies for the synthetic sample case."""
    system = text_of(messages[0])
    if system == prompts.SUMMARY_SYSTEM:
        return AIMessage(content=SAMPLE_SUMMARY)
    if system == prompts.DISCOVER_SYSTEM:
        return ai(call("submit_leads", leads=SAMPLE_LEADS))
    first_human = next(m for m in messages if isinstance(m, HumanMessage))
    label = re.search(r"^Candidate: (.+)$", text_of(first_human), flags=re.MULTILINE).group(1)
    script = next((s for key, s in SCRIPTS.items() if label.startswith(key)), None)
    if script is None:
        return AIMessage(content="No script for this candidate.")
    turn = sum(1 for m in messages if isinstance(m, AIMessage))
    return script[turn] if turn < len(script) else AIMessage(content="Script exhausted.")


def seed_sample_precedents(db: Database) -> None:
    """Three earlier corrections for the heart attack code family, as if from past cases."""
    for i, coder in enumerate(["coder-1", "coder-2", "coder-1"]):
        episodic.save_episode(
            db, setting="ER", payer="Payer A", code="I21.4", code_system="ICD-10-CM", decision="rejected",
            reason="uncertain_diagnosis", coder_id=coder, case_id=f"past-case-{i}", agent_bucket="confirmed",
            root_cause="agent_reasoning")


def main(sample_dir: Path) -> None:
    settings = Settings.from_env()
    db = Database(settings.database_url)
    db.migrate()
    print("Seeded", seed(db, sample_dir))
    registry = SkillRegistry.load(settings.skills_dir)
    procedural.sync_registry(db, registry)
    case = CaseIn(**json.loads((sample_dir / "er_case.json").read_text()))
    working.purge_case(db, case.case_id)
    working.create_case(db, case)
    if not episodic.precedents(db, "ER", "Payer A", "I21"):
        seed_sample_precedents(db)

    deps = Deps(db=db, model=ScriptedChatModel(responder=sample_responder), registry=registry, settings=settings)
    result = run_case(deps, case.case_id)
    print(f"\nFindings for {case.case_id}")
    for f in result["findings"]:
        pages = sorted({e["page"] for e in f["evidence"]})
        print(f"  {f['bucket']:<12} {f['code']:<7} {f['description']}  (evidence pages {pages}, skill {f['skill_id']})")
    stats = case_stats(db, settings, case.case_id)
    print("\nRun stats")
    for key in ("pages", "pages_opened", "record_tokens_estimate", "peak_context_tokens", "input_tokens",
                "output_tokens", "model_calls", "tool_calls", "reasoning_cost"):
        print(f"  {key}: {stats[key]}")
    db.close()


if __name__ == "__main__":
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else Path("data/sample"))
