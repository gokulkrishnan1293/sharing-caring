from __future__ import annotations

from typing import Any, Sequence

from langchain_core.messages import AIMessage, BaseMessage


def get_chat_model(spec: str) -> Any:
    """Build a chat model from "<provider>:<model id>". Needs the optional `llm` extra and the provider package."""
    if not spec:
        raise RuntimeError("No model configured. Set CLAIRE_MODEL to '<provider>:<model id>'.")
    try:
        from langchain.chat_models import init_chat_model
    except ImportError as exc:
        raise RuntimeError("Install the model extra first: pip install -e '.[llm]' plus your provider package.") from exc
    return init_chat_model(spec)


def text_of(message: BaseMessage) -> str:
    content = message.content
    if isinstance(content, str):
        return content
    return " ".join(part.get("text", "") if isinstance(part, dict) else str(part) for part in content)


def est_tokens(text: str) -> int:
    """Rough token estimate (about four characters per token), used only when the provider reports no usage."""
    return (len(text) + 3) // 4 if text else 0


def message_tokens(message: BaseMessage) -> int:
    extra = str(getattr(message, "tool_calls", "") or "")
    return est_tokens(text_of(message)) + est_tokens(extra)


def usage_of(ai: AIMessage, sent: Sequence[BaseMessage]) -> tuple[int, int]:
    """Input and output tokens for one call: the provider's numbers when present, an estimate otherwise."""
    usage = getattr(ai, "usage_metadata", None)
    if usage:
        return int(usage.get("input_tokens", 0)), int(usage.get("output_tokens", 0))
    return sum(message_tokens(m) for m in sent), message_tokens(ai)
