"""CLAIRE ER coding agent with four memory layers."""

__version__ = "0.1.0"
