"""The tools the coding agent can call. Each one reaches into a memory layer and returns a small slice."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from .memory import episodic, semantic, working
from .models import EvidenceIn

# Which memory layer each tool reads, and how its result is counted in the context breakdown
TOOL_LAYER = {
    "load_skill": "procedural", "lookup_code": "semantic", "get_precedents": "episodic",
    "find_pages": "working", "search_text": "working", "read_page": "working", "submit_verdict": "working",
}
TOOL_CONTEXT = {"load_skill": "skill", "get_precedents": "feedback", "read_page": "pages"}


@dataclass
class Scratch:
    """Per-candidate state the tools update as the agent works."""
    pages_read: list[int] = field(default_factory=list)
    skills_loaded: list[tuple[str, str]] = field(default_factory=list)
    precedent_ids: list[int] = field(default_factory=list)


class LoadSkillArgs(BaseModel):
    skill_id: str = Field(description="Id of the skill to load, from the list of available skills")


class FindPagesArgs(BaseModel):
    term: str = Field(description="A problem, drug, procedure or value to look for in the page index cards")
    page_type: str | None = Field(default=None, description="Optional page type filter, for example 'lab'")


class SearchTextArgs(BaseModel):
    query: str = Field(description="Words to search for in the full record text; join alternatives with OR")


class ReadPageArgs(BaseModel):
    page_num: int = Field(description="Page number to read in full")


class LookupCodeArgs(BaseModel):
    query: str = Field(description="A code such as 'E87.6', or words describing a diagnosis or service")


class PrecedentArgs(BaseModel):
    code: str = Field(description="The code to fetch past coder feedback for")
    code_system: Literal["ICD-10-CM", "CPT", "HCPCS"] = "ICD-10-CM"


class VerdictArgs(BaseModel):
    supported: bool = Field(description="True if the record supports reporting this code under the setting rules")
    code: str = Field(description="The code this verdict is about")
    code_system: Literal["ICD-10-CM", "CPT", "HCPCS"]
    rationale: str = Field(description="One or two sentences giving the reason for the verdict")
    evidence: list[EvidenceIn] = Field(default_factory=list, description="Exact quotes with page numbers")


class Lead(BaseModel):
    term: str = Field(description="The diagnosis or service as the record words it")
    kind: Literal["diagnosis", "service"]
    pages: list[int] = Field(default_factory=list)
    why: str = Field(description="Why this may be reportable and is not covered by the handled codes")


class LeadsArgs(BaseModel):
    leads: list[Lead]


def _dump(value: Any) -> str:
    return json.dumps(value, default=str)


def build_tools(deps: Any, case: dict, cards: list[dict], pages_text: dict[int, str],
                scratch: Scratch) -> list[StructuredTool]:
    db, registry, settings = deps.db, deps.registry, deps.settings

    def load_skill(skill_id: str) -> str:
        skill = registry.get(skill_id)
        if not skill:
            return f"Error: no skill named '{skill_id}'. Available: {', '.join(registry.skills)}"
        scratch.skills_loaded.append((skill.skill_id, skill.version))
        return f"Skill {skill.skill_id} v{skill.version}: {skill.title}\n\n{skill.body}"

    def find_pages(term: str, page_type: str | None = None) -> str:
        return _dump(working.find_pages(cards, term, page_type))

    def search_text(query: str) -> str:
        return _dump(working.search_text(pages_text, query))

    def read_page(page_num: int) -> str:
        if page_num not in pages_text:
            return f"Error: the record has no page {page_num}."
        if page_num not in scratch.pages_read:
            if len(scratch.pages_read) >= settings.max_pages_per_candidate:
                return (f"Error: page budget of {settings.max_pages_per_candidate} reached for this candidate. "
                        "Give your verdict from what you have read.")
            scratch.pages_read.append(page_num)
        return f"Page {page_num}\n{pages_text[page_num]}"

    def lookup_code(query: str) -> str:
        rows = semantic.lookup_code(db, query)
        return _dump(rows) if rows else "No matching code in the reference code set."

    def get_precedents(code: str, code_system: str = "ICD-10-CM") -> str:
        rows = episodic.precedents(db, case["setting"], case["payer"], episodic.code_family(code, code_system),
                                   settings.precedent_limit)
        for row in rows:
            scratch.precedent_ids.extend(i for i in row["episode_ids"] if i not in scratch.precedent_ids)
        return "\n".join(f"- {r['text']}" for r in rows) if rows else "No past coder feedback for this code family."

    def submit_verdict(supported: bool, code: str, code_system: str, rationale: str,
                       evidence: list[EvidenceIn] | None = None) -> str:
        return "Verdict recorded."

    def tool(fn, schema, description):
        return StructuredTool.from_function(func=fn, name=fn.__name__, description=description, args_schema=schema)

    return [
        tool(load_skill, LoadSkillArgs, "Load one skill: the evidence checklist and decision rules for a condition or service."),
        tool(find_pages, FindPagesArgs, "Query the page map for pages whose index card lists a term."),
        tool(search_text, SearchTextArgs, "Search the full text of every page. Use it for anything the page map may have missed."),
        tool(read_page, ReadPageArgs, "Read one page in full. Quotes in a verdict must come from pages read this way."),
        tool(lookup_code, LookupCodeArgs, "Look up a code or search the reference code set by description."),
        tool(get_precedents, PrecedentArgs, "Fetch past coder corrections for a code's family and this payer."),
        tool(submit_verdict, VerdictArgs, "Give the final verdict for the candidate. Call this exactly once, last."),
    ]


def leads_tool() -> StructuredTool:
    def submit_leads(leads: list[Lead]) -> str:
        return "Leads recorded."

    return StructuredTool.from_function(func=submit_leads, name="submit_leads", args_schema=LeadsArgs,
                                        description="Report the leads worth checking against the record.")
