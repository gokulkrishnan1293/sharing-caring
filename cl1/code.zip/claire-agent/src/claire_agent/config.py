from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    database_url: str = "postgresql://claire:claire@localhost:5432/claire"
    model: str = ""
    summary_model: str = ""
    skills_dir: Path = Path("skills")
    max_steps: int = 12
    max_pages_per_candidate: int = 10
    max_leads: int = 8
    precedent_limit: int = 3
    drift_flag_threshold: int = 3
    rate_input_per_mtok: float = 0.0
    rate_output_per_mtok: float = 0.0

    @classmethod
    def from_env(cls) -> "Settings":
        env = os.environ
        d = cls()
        return cls(
            database_url=env.get("DATABASE_URL", d.database_url),
            model=env.get("CLAIRE_MODEL", ""),
            summary_model=env.get("CLAIRE_SUMMARY_MODEL", ""),
            skills_dir=Path(env.get("CLAIRE_SKILLS_DIR", "skills")),
            max_steps=int(env.get("CLAIRE_MAX_STEPS", d.max_steps)),
            max_pages_per_candidate=int(env.get("CLAIRE_MAX_PAGES_PER_CANDIDATE", d.max_pages_per_candidate)),
            max_leads=int(env.get("CLAIRE_MAX_LEADS", d.max_leads)),
            precedent_limit=int(env.get("CLAIRE_PRECEDENT_LIMIT", d.precedent_limit)),
            drift_flag_threshold=int(env.get("CLAIRE_DRIFT_FLAG_THRESHOLD", d.drift_flag_threshold)),
            rate_input_per_mtok=float(env.get("CLAIRE_RATE_INPUT", 0) or 0),
            rate_output_per_mtok=float(env.get("CLAIRE_RATE_OUTPUT", 0) or 0),
        )
