"""Load reference codes and code-pair edits from CSV files into semantic memory.

Usage: python -m claire_agent.seed <folder with codes.csv and code_pair_edits.csv>
"""
from __future__ import annotations

import sys
from pathlib import Path

from .config import Settings
from .db import Database
from .memory import semantic


def seed(db: Database, folder: Path) -> dict:
    out = {"codes": semantic.load_codes_csv(db, folder / "codes.csv")}
    edits = folder / "code_pair_edits.csv"
    out["pair_edits"] = semantic.load_pair_edits_csv(db, edits) if edits.exists() else 0
    return out


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    database = Database(Settings.from_env().database_url)
    database.migrate()
    print(seed(database, Path(sys.argv[1])))
    database.close()
