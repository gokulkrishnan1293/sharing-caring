"""Coder review. Accepting closes a finding; rejecting or correcting it writes an episode at once."""
from __future__ import annotations

from .config import Settings
from .db import Database
from .memory import episodic, procedural, semantic, working
from .models import MissedCodeIn, ReviewIn, kind_of


def _close_case_if_done(db: Database, case_id: str) -> str:
    status = "reviewed" if working.pending_count(db, case_id) == 0 else "awaiting_review"
    working.set_status(db, case_id, status)
    return status


def record_review(db: Database, settings: Settings, finding_id: int, review: ReviewIn) -> dict:
    finding = working.get_finding(db, finding_id)
    if finding is None:
        raise LookupError(f"unknown finding {finding_id}")
    if finding["review_status"] != "pending":
        raise ValueError(f"finding {finding_id} was already reviewed ({finding['review_status']})")
    case = working.get_case(db, finding["case_id"])

    if review.decision == "accept":
        working.set_review_status(db, finding_id, "accepted")
        return {"finding_id": finding_id, "review_status": "accepted", "episode_id": None,
                "case_status": _close_case_if_done(db, case["case_id"])}

    if review.reason is None:
        raise ValueError("a reason is required when rejecting or correcting a finding")
    if review.decision == "correct" and not (review.corrected_code and review.corrected_code_system):
        raise ValueError("corrected_code and corrected_code_system are required for a correction")

    decision = "rejected" if review.decision == "reject" else "corrected"
    episode_id = episodic.save_episode(
        db, setting=case["setting"], payer=case["payer"], code=finding["code"], code_system=finding["code_system"],
        decision=decision, reason=review.reason, coder_id=review.coder_id, case_id=case["case_id"],
        agent_bucket=finding["bucket"], corrected_code=review.corrected_code, root_cause=review.root_cause,
        note=review.note, skill_id=finding["skill_id"], skill_version=finding["skill_version"])
    working.set_review_status(db, finding_id, decision)

    drift = None
    if review.root_cause == "skill_gap" and finding["skill_id"]:
        count = procedural.flag_drift(db, finding["skill_id"], finding["skill_version"], episode_id)
        drift = {"skill_id": finding["skill_id"], "version": finding["skill_version"], "drift_flag_count": count,
                 "needs_fix": count >= settings.drift_flag_threshold}
    return {"finding_id": finding_id, "review_status": decision, "episode_id": episode_id, "drift": drift,
            "case_status": _close_case_if_done(db, case["case_id"])}


def add_missed_code(db: Database, settings: Settings, case_id: str, missed: MissedCodeIn) -> dict:
    """A coder adds a code the agent never proposed. Saved as a finding and as an episode."""
    case = working.get_case(db, case_id)
    if case is None:
        raise LookupError(f"unknown case {case_id}")
    code = missed.code.strip().upper()
    reference = semantic.get_code(db, code, missed.code_system)
    episode_id = episodic.save_episode(
        db, setting=case["setting"], payer=case["payer"], code=code, code_system=missed.code_system,
        decision="added", reason=missed.reason, coder_id=missed.coder_id, case_id=case_id,
        root_cause=missed.root_cause, note=missed.note)
    finding_id = working.save_finding(db, case_id, {
        "code": code, "code_system": missed.code_system, "kind": kind_of(missed.code_system), "source": "coder",
        "bucket": "missed", "description": reference["description"] if reference else None,
        "rationale": "Added by a coder.", "review_status": "added",
        "flags": [] if reference else [{"type": "code_not_in_reference"}]}, [])
    return {"finding_id": finding_id, "episode_id": episode_id}
