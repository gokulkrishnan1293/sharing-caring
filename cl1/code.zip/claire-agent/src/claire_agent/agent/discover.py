"""Discover pass: compare what the page map lists with what has been handled, and propose leads."""
from __future__ import annotations

import json
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage

from .. import prompts
from ..llm import usage_of
from ..tools import LeadsArgs, leads_tool
from ..trace import Tracer


def inventory(cards: list[dict]) -> dict[str, dict[str, list[int]]]:
    """Everything the index cards list, with the pages each item appears on."""
    out: dict[str, dict[str, list[int]]] = {"problems": {}, "medications": {}, "procedures": {}, "abnormal_values": {}}
    for card in cards:
        for field in out:
            for item in card.get(field, []):
                out[field].setdefault(item.strip().lower(), []).append(card["page"])
    return out


def find_leads(deps: Any, case: dict, cards: list[dict], handled: list[dict], tracer: Tracer) -> list[dict]:
    tool = leads_tool()
    model = deps.model.bind_tools([tool])
    handled_lines = [f"- {h['code']} ({h['code_system']}) {h.get('description') or ''}: {h['status']}" for h in handled]
    human = "\n".join([
        "Case summary", case["case_summary"], "",
        "Codes already handled", *(handled_lines or ["- none"]), "",
        "Inventory from the page index cards (item: pages)", json.dumps(inventory(cards)),
    ])
    messages = [SystemMessage(prompts.DISCOVER_SYSTEM), HumanMessage(human)]
    ai = model.invoke(messages)
    tokens_in, tokens_out = usage_of(ai, messages)
    tracer.emit("discover", "llm", detail={"handled": len(handled)}, input_tokens=tokens_in, output_tokens=tokens_out)

    leads: list[dict] = []
    for call in getattr(ai, "tool_calls", None) or []:
        if call["name"] != "submit_leads":
            continue
        try:
            parsed = LeadsArgs(**(call.get("args") or {}))
        except Exception as exc:
            tracer.emit("discover", "result", detail={"error": f"leads rejected: {exc}"})
            continue
        for lead in parsed.leads[: deps.settings.max_leads]:
            leads.append({"source": "lead", "kind": lead.kind, "label": lead.term, "term": lead.term,
                          "pages": lead.pages, "why": lead.why, "code": None, "code_system": None})
    tracer.emit("discover", "node", detail={"leads": [l["label"] for l in leads]})
    return leads
