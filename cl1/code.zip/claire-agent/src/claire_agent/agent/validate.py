"""Checks applied in code after the agent's verdict. The model's say-so is never enough on its own."""
from __future__ import annotations

import re

_TRANSLATE = str.maketrans({"‘": "'", "’": "'", "“": '"', "”": '"', "–": "-", "—": "-"})
MIN_QUOTE_CHARS = 8


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text.translate(_TRANSLATE)).strip().lower()


def verify_evidence(pages_text: dict[int, str], evidence: list[dict]) -> list[dict]:
    """Mark each quote verified only if it appears on the page it cites. Catches invented evidence."""
    cache: dict[int, str] = {}
    out = []
    for ev in evidence:
        page, quote = ev["page"], normalize(ev["quote"])
        if page in pages_text and page not in cache:
            cache[page] = normalize(pages_text[page])
        verified = len(quote) >= MIN_QUOTE_CHARS and quote in cache.get(page, "")
        out.append({**ev, "verified": verified})
    return out


def ontology_gaps(requirements: dict, evidence: list[dict]) -> list[str]:
    """Which required evidence tags are missing among the verified quotes."""
    tags = {ev["supports"] for ev in evidence if ev["verified"]}
    gaps = [tag for tag in requirements.get("require_all", []) if tag not in tags]
    any_of = requirements.get("require_any", [])
    if any_of and not tags.intersection(any_of):
        gaps.append("one of: " + ", ".join(any_of))
    return gaps


def decide_bucket(source: str, supported: bool, flags: list[dict]) -> str | None:
    """Map a verdict to a review bucket. None means a lead that did not hold up and is dropped."""
    blocking = [f for f in flags if f["type"] in ("unverified_quote", "ontology_gap", "code_not_in_reference")]
    if source == "claim":
        if not supported:
            return "unsupported"
        return "needs_review" if blocking else "confirmed"
    if not supported:
        return None
    return "needs_review" if blocking else "missed"
