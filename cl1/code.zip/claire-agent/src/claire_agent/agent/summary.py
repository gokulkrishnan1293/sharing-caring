"""Case summary: one text-only roll-up of the page index cards. It is the only record content always in context."""
from __future__ import annotations

from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage

from .. import prompts
from ..llm import text_of, usage_of
from ..memory import working
from ..trace import Tracer

CHUNK = 60


def _summarise(model: Any, text: str, tracer: Tracer, note: str) -> str:
    messages = [SystemMessage(prompts.SUMMARY_SYSTEM), HumanMessage(text)]
    ai = model.invoke(messages)
    tokens_in, tokens_out = usage_of(ai, messages)
    tracer.emit("case_summary", "llm", detail={"step": note}, input_tokens=tokens_in, output_tokens=tokens_out)
    return text_of(ai).strip()


def ensure_summary(deps: Any, case: dict, cards: list[dict], tracer: Tracer) -> str:
    if case.get("case_summary"):
        return case["case_summary"]
    model = deps.summary_model or deps.model
    lines = [prompts.card_line(c) for c in cards]
    if len(lines) <= CHUNK * 2:
        summary = _summarise(model, "Page index cards\n" + "\n".join(lines), tracer, "roll-up")
    else:
        # Long records: summarise blocks of cards, then summarise the block summaries
        parts = [
            _summarise(model, "Page index cards\n" + "\n".join(lines[i:i + CHUNK]), tracer, f"block {i // CHUNK + 1}")
            for i in range(0, len(lines), CHUNK)
        ]
        summary = _summarise(model, "Block summaries of one record, in page order\n" + "\n\n".join(parts),
                             tracer, "combine")
    working.set_summary(deps.db, case["case_id"], summary)
    tracer.emit("case_summary", "memory", detail={"layer": "working", "stored": "case summary"})
    return summary
