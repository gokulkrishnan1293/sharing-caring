"""The bounded loop for one candidate: load a skill, find and read pages, check the code, give a verdict."""
from __future__ import annotations

import json
from typing import Any

from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage, ToolMessage

from .. import prompts
from ..llm import message_tokens, usage_of
from ..memory import episodic
from ..tools import TOOL_CONTEXT, TOOL_LAYER, Scratch, VerdictArgs, build_tools
from ..trace import Tracer


def _breakdown(messages: list[BaseMessage], cats: list[str]) -> dict[str, int]:
    out: dict[str, int] = {}
    for message, cat in zip(messages, cats):
        out[cat] = out.get(cat, 0) + message_tokens(message)
    return out


def run_candidate(deps: Any, case: dict, cards: list[dict], pages_text: dict[int, str], cand: dict,
                  tracer: Tracer) -> dict:
    settings, label = deps.settings, cand["label"]
    scratch = Scratch()
    tools = build_tools(deps, case, cards, pages_text, scratch)
    by_name = {t.name: t for t in tools}
    model = deps.model.bind_tools(tools)

    # Episodic memory is fetched by code, not left to the agent, whenever the code is already known
    prior: list[dict] = []
    if cand.get("code"):
        family = episodic.code_family(cand["code"], cand["code_system"])
        prior = episodic.precedents(deps.db, case["setting"], case["payer"], family, settings.precedent_limit)
        for row in prior:
            scratch.precedent_ids.extend(row["episode_ids"])
        if prior:
            tracer.emit("code_loop", "memory", label,
                        {"layer": "episodic", "precedents": len(prior), "episode_ids": scratch.precedent_ids})

    messages: list[BaseMessage] = [
        SystemMessage(prompts.coder_system(deps.registry, case["setting"])),
        HumanMessage(prompts.candidate_message(case["case_summary"], cand, prior)),
    ]
    cats = ["system", "case"]
    verdict: VerdictArgs | None = None
    nudged = False
    steps = 0

    while steps < settings.max_steps and verdict is None:
        steps += 1
        context = _breakdown(messages, cats)
        ai = model.invoke(messages)
        tokens_in, tokens_out = usage_of(ai, messages)
        calls = list(getattr(ai, "tool_calls", None) or [])
        tracer.emit("code_loop", "llm", label,
                    {"step": steps, "context": context, "tool_calls": [c["name"] for c in calls]},
                    input_tokens=tokens_in, output_tokens=tokens_out, context_tokens=sum(context.values()))
        messages.append(ai)
        cats.append("reasoning")

        if not calls:
            if nudged:
                break
            messages.append(HumanMessage("Finish by calling submit_verdict."))
            cats.append("case")
            nudged = True
            continue

        for call in calls:
            name, args = call["name"], call.get("args") or {}
            if name not in by_name:
                result = f"Error: unknown tool '{name}'."
            else:
                try:
                    result = by_name[name].invoke(args)
                    if name == "submit_verdict":
                        verdict = VerdictArgs(**args)
                except Exception as exc:  # bad arguments go back to the model so it can correct them
                    result = f"Error: {exc}"
            if not isinstance(result, str):
                result = json.dumps(result, default=str)
            messages.append(ToolMessage(content=result, tool_call_id=call["id"]))
            cats.append(TOOL_CONTEXT.get(name, "tools"))
            kind = "memory" if TOOL_LAYER.get(name) in ("procedural", "semantic", "episodic") else "tool"
            tracer.emit("code_loop", kind, label,
                        {"tool": name, "layer": TOOL_LAYER.get(name), "args": args,
                         "result_tokens": message_tokens(messages[-1]), "error": result.startswith("Error:")})

    skill_id, skill_version = scratch.skills_loaded[-1] if scratch.skills_loaded else (None, None)
    return {
        "verdict": verdict,
        "steps": steps,
        "pages_read": sorted(scratch.pages_read),
        "skill_id": skill_id,
        "skill_version": skill_version,
        "precedent_ids": scratch.precedent_ids,
    }
