"""The pipeline. The outer flow is fixed; the agent's freedom is bounded to the per-candidate loop."""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any, TypedDict

from langgraph.graph import END, START, StateGraph

from ..config import Settings
from ..db import Database
from ..memory import semantic, working
from ..memory.procedural import SkillRegistry
from ..models import is_em_code, kind_of
from ..trace import Tracer
from . import validate
from .coder import run_candidate
from .discover import find_leads
from .summary import ensure_summary


@dataclass
class Deps:
    db: Database
    model: Any
    registry: SkillRegistry
    settings: Settings
    summary_model: Any = None


class RunState(TypedDict):
    case_id: str
    run_id: str
    queue: list[dict]
    discovered: bool


@dataclass
class _RunCtx:
    case: dict
    cards: list[dict]
    pages_text: dict[int, str]
    tracer: Tracer


def _process(deps: Deps, rc: _RunCtx, cand: dict) -> None:
    db, label = deps.db, cand["label"]
    case_id = rc.case["case_id"]
    result = run_candidate(deps, rc.case, rc.cards, rc.pages_text, cand, rc.tracer)
    verdict = result["verdict"]
    base = {"source": cand["source"], "skill_id": result["skill_id"], "skill_version": result["skill_version"],
            "precedent_ids": result["precedent_ids"], "pages_read": result["pages_read"]}

    if verdict is None:
        if cand["source"] == "claim":
            working.save_finding(db, case_id, {
                **base, "code": cand["code"], "code_system": cand["code_system"],
                "description": cand.get("description"), "kind": cand["kind"], "bucket": "needs_review",
                "rationale": "The agent reached its step budget without a verdict.",
                "flags": [{"type": "no_verdict", "steps": result["steps"]}]}, [])
            rc.tracer.emit("verdict", "result", label, {"bucket": "needs_review", "reason": "step budget reached"})
        else:
            rc.tracer.emit("verdict", "result", label, {"dropped": "lead reached the step budget without a verdict"})
        return

    flags: list[dict] = []
    if cand["source"] == "claim":
        code, code_system = cand["code"], cand["code_system"]
        if verdict.code.strip().upper() != code:
            flags.append({"type": "agent_suggested_code", "code": verdict.code.strip().upper(),
                          "code_system": verdict.code_system})
    else:
        code, code_system = verdict.code.strip().upper(), verdict.code_system

    reference = semantic.get_code(db, code, code_system)
    if not reference:
        flags.append({"type": "code_not_in_reference"})
    evidence = validate.verify_evidence(rc.pages_text, [e.model_dump() for e in verdict.evidence])
    bad_pages = sorted({e["page"] for e in evidence if not e["verified"]})
    if bad_pages:
        flags.append({"type": "unverified_quote", "pages": bad_pages})
    kind = kind_of(code_system)
    if verdict.supported:
        gaps = validate.ontology_gaps(deps.registry.requirements(kind), evidence)
        if gaps:
            flags.append({"type": "ontology_gap", "missing": gaps})

    bucket = validate.decide_bucket(cand["source"], verdict.supported, flags)
    if bucket is None:
        rc.tracer.emit("verdict", "result", label, {"dropped": "lead not supported", "code": code,
                                                    "rationale": verdict.rationale})
        return
    if cand["source"] == "lead":
        existing = {f["code"] for f in working.list_findings(db, case_id)}
        on_claim = {c["code"].upper() for c in rc.case["claim_codes"]}
        if code in existing or code in on_claim:
            rc.tracer.emit("verdict", "result", label, {"dropped": "already handled", "code": code})
            return

    working.save_finding(db, case_id, {
        **base, "code": code, "code_system": code_system, "kind": kind, "bucket": bucket,
        "description": reference["description"] if reference else cand.get("description"),
        "rationale": verdict.rationale, "flags": flags}, evidence)
    rc.tracer.emit("verdict", "result", label, {"bucket": bucket, "code": code, "flags": [f["type"] for f in flags]})


def build_graph(deps: Deps, checkpointer: Any = None):
    runs: dict[str, _RunCtx] = {}

    def ctx(state: RunState) -> _RunCtx:
        if state["run_id"] not in runs:
            case = working.get_case(deps.db, state["case_id"])
            if case is None:
                raise ValueError(f"unknown case {state['case_id']}")
            runs[state["run_id"]] = _RunCtx(
                case=case, cards=working.get_cards(deps.db, case["case_id"]),
                pages_text=working.get_pages_text(deps.db, case["case_id"]),
                tracer=Tracer(deps.db, case["case_id"], state["run_id"]))
        return runs[state["run_id"]]

    def prepare(state: RunState) -> dict:
        db, case_id = deps.db, state["case_id"]
        working.clear_run(db, case_id)
        working.set_status(db, case_id, "running")
        rc = ctx(state)
        rc.tracer.emit("intake", "node", detail={"pages": len(rc.cards), "claim_codes": len(rc.case["claim_codes"])})
        rc.tracer.emit("page_map", "memory", detail={"layer": "working", "cards": len(rc.cards)})
        rc.case["case_summary"] = ensure_summary(deps, rc.case, rc.cards, rc.tracer)

        queue = []
        for claim in rc.case["claim_codes"]:
            code, code_system = claim["code"].strip().upper(), claim["code_system"]
            if is_em_code(code, code_system):
                rc.tracer.emit("plan", "result", code, {"skipped": "visit-level code, out of scope"})
                continue
            reference = semantic.get_code(db, code, code_system)
            description = reference["description"] if reference else None
            queue.append({"source": "claim", "kind": kind_of(code_system), "code": code, "code_system": code_system,
                          "description": description, "label": f"{code} ({code_system})"})
        rc.tracer.emit("plan", "node", detail={"rule_pack": rc.case["setting"], "phase": "verify",
                                               "candidates": [c["label"] for c in queue]})
        return {"queue": queue, "discovered": False}

    def work(state: RunState) -> dict:
        cand, rest = state["queue"][0], state["queue"][1:]
        _process(deps, ctx(state), cand)
        return {"queue": rest}

    def discover(state: RunState) -> dict:
        rc = ctx(state)
        handled = [{"code": f["code"], "code_system": f["code_system"], "description": f["description"],
                    "status": f["bucket"]} for f in working.list_findings(deps.db, state["case_id"])]
        leads = find_leads(deps, rc.case, rc.cards, handled, rc.tracer)
        return {"queue": leads, "discovered": True}

    def finalize(state: RunState) -> dict:
        db, case_id = deps.db, state["case_id"]
        rc = ctx(state)
        findings = working.list_findings(db, case_id)
        reportable = {f["code"]: f["finding_id"] for f in findings if f["bucket"] in ("confirmed", "missed")}
        for conflict in semantic.pair_conflicts(db, list(reportable)):
            working.add_flag(db, reportable[conflict["code_a"]], {
                "type": "pair_edit", "with": conflict["code_b"], "kind": conflict["kind"], "note": conflict["note"]})
        counts: dict[str, int] = {}
        for f in findings:
            counts[f["bucket"]] = counts.get(f["bucket"], 0) + 1
        working.set_status(db, case_id, "awaiting_review")
        rc.tracer.emit("coder_review", "result", detail={"findings": counts})
        runs.pop(state["run_id"], None)
        return {}

    def route(state: RunState) -> str:
        if state["queue"]:
            return "work"
        return "finalize" if state["discovered"] else "discover"

    graph = StateGraph(RunState)
    for name, fn in (("prepare", prepare), ("work", work), ("discover", discover), ("finalize", finalize)):
        graph.add_node(name, fn)
    graph.add_edge(START, "prepare")
    targets = {"work": "work", "discover": "discover", "finalize": "finalize"}
    for node in ("prepare", "work", "discover"):
        graph.add_conditional_edges(node, route, targets)
    graph.add_edge("finalize", END)
    return graph.compile(checkpointer=checkpointer)


def run_case(deps: Deps, case_id: str) -> dict:
    """Run the agent on one ingested case and return its findings."""
    if working.get_case(deps.db, case_id) is None:
        raise ValueError(f"unknown case {case_id}")
    graph = build_graph(deps)
    state: RunState = {"case_id": case_id, "run_id": uuid.uuid4().hex, "queue": [], "discovered": False}
    try:
        graph.invoke(state, config={"recursion_limit": 500})
    except Exception:
        working.set_status(deps.db, case_id, "failed")
        raise
    return {"case_id": case_id, "findings": working.list_findings(deps.db, case_id)}
