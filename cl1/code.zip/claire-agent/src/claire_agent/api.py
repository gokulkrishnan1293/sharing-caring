"""HTTP API for ingesting cases, running the agent, reviewing findings and reading memory."""
from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Literal

from fastapi import FastAPI, HTTPException
from psycopg.errors import UniqueViolation

from . import review as review_mod
from . import trace as trace_mod
from .agent.graph import Deps, run_case
from .config import Settings
from .db import Database
from .llm import get_chat_model
from .memory import episodic, procedural, working
from .memory.procedural import SkillRegistry
from .models import CaseIn, MissedCodeIn, ReviewIn


def deps_from_env() -> Deps:
    settings = Settings.from_env()
    db = Database(settings.database_url)
    db.migrate()
    registry = SkillRegistry.load(settings.skills_dir)
    procedural.sync_registry(db, registry)
    model = get_chat_model(settings.model) if settings.model else None
    summary_model = get_chat_model(settings.summary_model) if settings.summary_model else None
    return Deps(db=db, model=model, registry=registry, settings=settings, summary_model=summary_model)


def create_app(deps: Deps | None = None) -> FastAPI:
    state: dict[str, Deps] = {}

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        state["deps"] = deps or deps_from_env()
        yield
        if deps is None:
            state["deps"].db.close()

    app = FastAPI(title="CLAIRE ER coding agent", version="0.1.0", lifespan=lifespan)

    def d() -> Deps:
        return state["deps"]

    def case_or_404(case_id: str) -> dict:
        case = working.get_case(d().db, case_id)
        if case is None:
            raise HTTPException(404, f"unknown case {case_id}")
        return case

    @app.get("/health")
    def health() -> dict:
        return {"ok": True, "model_configured": d().model is not None, "skills": len(d().registry.skills)}

    @app.post("/cases", status_code=201)
    def ingest_case(case: CaseIn) -> dict:
        try:
            working.create_case(d().db, case)
        except UniqueViolation:
            raise HTTPException(409, f"case {case.case_id} already exists")
        return {"case_id": case.case_id, "pages": len(case.pages)}

    @app.get("/cases")
    def list_cases() -> list[dict]:
        return working.list_cases(d().db)

    @app.get("/cases/{case_id}")
    def get_case(case_id: str) -> dict:
        case = case_or_404(case_id)
        return {**case, "page_map": working.get_cards(d().db, case_id)}

    @app.get("/cases/{case_id}/pages/{page_num}")
    def get_page(case_id: str, page_num: int) -> dict:
        case_or_404(case_id)
        page = working.get_page(d().db, case_id, page_num)
        if page is None:
            raise HTTPException(404, f"case {case_id} has no page {page_num}")
        return page

    @app.post("/cases/{case_id}/run")
    def run(case_id: str) -> dict:
        case_or_404(case_id)
        if d().model is None:
            raise HTTPException(503, "No model configured. Set CLAIRE_MODEL and restart.")
        return run_case(d(), case_id)

    @app.get("/cases/{case_id}/findings")
    def findings(case_id: str) -> list[dict]:
        case_or_404(case_id)
        return working.list_findings(d().db, case_id)

    @app.get("/cases/{case_id}/trace")
    def trace(case_id: str) -> list[dict]:
        case_or_404(case_id)
        return trace_mod.get_trace(d().db, case_id)

    @app.get("/cases/{case_id}/stats")
    def case_stats(case_id: str) -> dict:
        case_or_404(case_id)
        return trace_mod.case_stats(d().db, d().settings, case_id)

    @app.delete("/cases/{case_id}", status_code=204)
    def purge(case_id: str) -> None:
        case_or_404(case_id)
        working.purge_case(d().db, case_id)

    @app.post("/findings/{finding_id}/review")
    def review(finding_id: int, body: ReviewIn) -> dict:
        try:
            return review_mod.record_review(d().db, d().settings, finding_id, body)
        except LookupError as exc:
            raise HTTPException(404, str(exc))
        except ValueError as exc:
            raise HTTPException(422, str(exc))

    @app.post("/cases/{case_id}/missed-codes", status_code=201)
    def missed_code(case_id: str, body: MissedCodeIn) -> dict:
        try:
            return review_mod.add_missed_code(d().db, d().settings, case_id, body)
        except LookupError as exc:
            raise HTTPException(404, str(exc))
        except ValueError as exc:
            raise HTTPException(422, str(exc))

    @app.get("/episodes")
    def episodes(limit: int = 100) -> list[dict]:
        return episodic.list_episodes(d().db, limit)

    @app.get("/precedents")
    def precedents(payer: str, code: str, code_system: Literal["ICD-10-CM", "CPT", "HCPCS"] = "ICD-10-CM",
                   setting: str = "ER") -> list[dict]:
        family = episodic.code_family(code, code_system)
        return episodic.precedents(d().db, setting, payer, family, d().settings.precedent_limit)

    @app.get("/skills")
    def skills() -> list[dict]:
        flags = {(r["skill_id"], r["version"]): r["drift_flag_count"]
                 for r in procedural.flagged_skills(d().db, 0)}
        return [{"skill_id": s.skill_id, "version": s.version, "title": s.title, "description": s.description,
                 "applies_to": list(s.applies_to), "drift_flag_count": flags.get((s.skill_id, s.version), 0)}
                for s in d().registry.skills.values()]

    @app.get("/skills/flagged")
    def flagged() -> list[dict]:
        return procedural.flagged_skills(d().db, d().settings.drift_flag_threshold)

    @app.get("/stats")
    def stats() -> dict:
        return trace_mod.overall_stats(d().db, d().settings)

    return app


def app_from_env() -> FastAPI:
    """Entry point for `uvicorn claire_agent.api:app_from_env --factory`."""
    return create_app()
