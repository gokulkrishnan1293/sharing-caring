-- Working memory: one case, cleared with purge_case when the case is closed
CREATE TABLE IF NOT EXISTS cases (
    case_id      TEXT PRIMARY KEY,
    setting      TEXT NOT NULL DEFAULT 'ER',
    payer        TEXT NOT NULL,
    claim_codes  JSONB NOT NULL DEFAULT '[]',
    case_summary TEXT,
    status       TEXT NOT NULL DEFAULT 'ingested',
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS case_pages (
    case_id   TEXT NOT NULL REFERENCES cases ON DELETE CASCADE,
    page_num  INT  NOT NULL,
    page_text TEXT NOT NULL,
    card      JSONB NOT NULL,
    PRIMARY KEY (case_id, page_num)
);

CREATE TABLE IF NOT EXISTS findings (
    finding_id    BIGSERIAL PRIMARY KEY,
    case_id       TEXT NOT NULL REFERENCES cases ON DELETE CASCADE,
    code          TEXT NOT NULL,
    code_system   TEXT NOT NULL,
    description   TEXT,
    kind          TEXT NOT NULL,
    source        TEXT NOT NULL,
    bucket        TEXT NOT NULL,
    rationale     TEXT,
    skill_id      TEXT,
    skill_version TEXT,
    precedent_ids JSONB NOT NULL DEFAULT '[]',
    pages_read    JSONB NOT NULL DEFAULT '[]',
    flags         JSONB NOT NULL DEFAULT '[]',
    review_status TEXT NOT NULL DEFAULT 'pending',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS findings_case_idx ON findings (case_id);

-- Evidence ledger: every quote the agent relied on, with its page
CREATE TABLE IF NOT EXISTS evidence (
    evidence_id BIGSERIAL PRIMARY KEY,
    finding_id  BIGINT NOT NULL REFERENCES findings ON DELETE CASCADE,
    page_num    INT NOT NULL,
    quote       TEXT NOT NULL,
    supports    TEXT NOT NULL,
    verified    BOOLEAN NOT NULL
);
CREATE INDEX IF NOT EXISTS evidence_finding_idx ON evidence (finding_id);

CREATE TABLE IF NOT EXISTS trace_events (
    event_id       BIGSERIAL PRIMARY KEY,
    case_id        TEXT NOT NULL REFERENCES cases ON DELETE CASCADE,
    run_id         TEXT NOT NULL,
    seq            INT NOT NULL,
    node           TEXT NOT NULL,
    kind           TEXT NOT NULL,
    candidate      TEXT,
    detail         JSONB NOT NULL DEFAULT '{}',
    input_tokens   INT NOT NULL DEFAULT 0,
    output_tokens  INT NOT NULL DEFAULT 0,
    context_tokens INT,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS trace_case_idx ON trace_events (case_id, seq);

-- Semantic memory: reference code sets, read-only to the agent
CREATE TABLE IF NOT EXISTS medical_codes (
    code        TEXT NOT NULL,
    code_system TEXT NOT NULL,
    description TEXT NOT NULL,
    search      tsvector GENERATED ALWAYS AS (to_tsvector('english', code || ' ' || description)) STORED,
    PRIMARY KEY (code_system, code)
);
CREATE INDEX IF NOT EXISTS medical_codes_search_idx ON medical_codes USING GIN (search);
CREATE INDEX IF NOT EXISTS medical_codes_code_idx ON medical_codes (code);

CREATE TABLE IF NOT EXISTS code_pair_edits (
    code_a TEXT NOT NULL,
    code_b TEXT NOT NULL,
    kind   TEXT NOT NULL,
    note   TEXT,
    PRIMARY KEY (code_a, code_b)
);

-- Procedural memory registry: skill text lives in versioned files, this tracks drift only
CREATE TABLE IF NOT EXISTS skills (
    skill_id              TEXT NOT NULL,
    version               TEXT NOT NULL,
    title                 TEXT NOT NULL,
    drift_flag_count      INT NOT NULL DEFAULT 0,
    last_drift_episode_id BIGINT,
    loaded_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (skill_id, version)
);

-- Episodic memory: coder corrections, structured, with no chart text
CREATE TABLE IF NOT EXISTS episodes (
    episode_id     BIGSERIAL PRIMARY KEY,
    setting        TEXT NOT NULL,
    payer          TEXT NOT NULL,
    code           TEXT NOT NULL,
    code_system    TEXT NOT NULL,
    code_family    TEXT NOT NULL,
    agent_bucket   TEXT,
    decision       TEXT NOT NULL,
    corrected_code TEXT,
    reason         TEXT NOT NULL,
    root_cause     TEXT NOT NULL DEFAULT 'none',
    note           TEXT,
    skill_id       TEXT,
    skill_version  TEXT,
    coder_id       TEXT NOT NULL,
    case_hash      TEXT NOT NULL,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS episodes_scope_idx ON episodes (setting, payer, code_family);
