"""The agent's prompts. They stay small: clinical knowledge lives in skills and is loaded on demand."""
from __future__ import annotations

from .memory.procedural import SkillRegistry

CODER_SYSTEM = """You are a medical coder reviewing one emergency department record. You check one candidate at a time and decide whether the record supports it.

How to work
1. Load the one skill that fits the candidate with load_skill before reading pages.
2. Find where the evidence is with find_pages and search_text, then read only those pages with read_page.
3. Confirm the code with lookup_code. If the candidate is a term and not a code, use lookup_code to choose the code.
4. Past coder feedback, when shown or returned by get_precedents, is precedent from human coders. Weigh it.
5. Finish with submit_verdict. Copy every quote exactly from a page you read, give its page number, and tag what it supports.

What a supported finding needs
{ontology}

Setting rules
{rule_pack}

Skills available
{skill_index}"""

DISCOVER_SYSTEM = """You look for leads in one emergency department record: diagnoses or services that the record mentions but the claim does not report.

You are given the case summary, the codes already handled, and an inventory of what the page index cards list. Compare them and call submit_leads once with the items worth checking. Include a drug or treatment that has no matching diagnosis among the handled codes. Leave out anything the handled codes already cover, visit-level codes, and normal findings. Each lead is checked against the record afterwards, so include plausible items and skip certain non-starters."""

SUMMARY_SYSTEM = """You write the case summary for one emergency department record from its page index cards. In at most 150 words, state why the patient came, the main problems, the tests and treatments, and the disposition, each with the page numbers where it is documented. Use only what the cards list."""


def render_ontology(registry: SkillRegistry) -> str:
    lines = []
    for kind, req in registry.ontology["value_types"].items():
        lines.append(
            f"- A {kind} needs verified quotes tagged with all of [{', '.join(req['require_all'])}] "
            f"and at least one of [{', '.join(req['require_any'])}]."
        )
        for tag, meaning in req.get("meaning", {}).items():
            lines.append(f"  - {tag}: {meaning}")
    return "\n".join(lines)


def coder_system(registry: SkillRegistry, setting: str) -> str:
    return CODER_SYSTEM.format(
        ontology=render_ontology(registry), rule_pack=registry.rule_pack(setting), skill_index=registry.index())


def candidate_message(summary: str, cand: dict, precedents: list[dict]) -> str:
    lines = ["Case summary", summary, "", f"Candidate: {cand['label']}"]
    if cand["source"] == "claim":
        lines.append("Source: on the claim")
        lines.append(f"Type: {cand['kind']}")
        if cand.get("description"):
            lines.append(f"Description: {cand['description']}")
        else:
            lines.append("Description: not found in the reference code set")
    else:
        lines.append("Source: lead from the record, not on the claim")
        lines.append(f"Type: {cand['kind']}")
        if cand.get("pages"):
            lines.append(f"Mentioned on pages: {', '.join(str(p) for p in cand['pages'])}")
        if cand.get("why"):
            lines.append(f"Why it is a lead: {cand['why']}")
    if precedents:
        lines += ["", "Past coder feedback for this code family and payer"]
        lines += [f"- {p['text']}" for p in precedents]
    return "\n".join(lines)


def card_line(card: dict) -> str:
    head = f"p.{card['page']} [{card.get('page_type', 'unknown')}"
    if card.get("date"):
        head += f", {card['date']}"
    if card.get("quality") and card["quality"] != "clean":
        head += f", {card['quality'].replace('_', ' ')}"
    head += "]"
    parts = []
    for label, key in (("problems", "problems"), ("meds", "medications"),
                       ("procedures", "procedures"), ("values", "abnormal_values")):
        if card.get(key):
            parts.append(f"{label}: {', '.join(card[key])}")
    return head + (" " + "; ".join(parts) if parts else "")
