"""A chat model that replays scripted replies, so the agent can be tested without calling a provider."""
from __future__ import annotations

from typing import Any, Callable, Sequence

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage
from langchain_core.outputs import ChatGeneration, ChatResult

from .llm import message_tokens


class ScriptedChatModel(BaseChatModel):
    """Calls `responder(messages)` to get each reply. Token usage is estimated from text length."""

    responder: Callable[[Sequence[BaseMessage]], AIMessage]

    @property
    def _llm_type(self) -> str:
        return "scripted"

    def bind_tools(self, tools: Any, **kwargs: Any) -> "ScriptedChatModel":
        return self

    def _generate(self, messages: list[BaseMessage], stop: Any = None, run_manager: Any = None,
                  **kwargs: Any) -> ChatResult:
        reply = self.responder(messages)
        if reply.usage_metadata is None:
            tokens_in = sum(message_tokens(m) for m in messages)
            tokens_out = message_tokens(reply)
            reply.usage_metadata = {"input_tokens": tokens_in, "output_tokens": tokens_out,
                                    "total_tokens": tokens_in + tokens_out}
        return ChatResult(generations=[ChatGeneration(message=reply)])
