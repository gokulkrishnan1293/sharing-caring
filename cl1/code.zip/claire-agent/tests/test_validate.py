from claire_agent.agent import validate
from claire_agent.memory import episodic
import pytest

PAGES = {1: "Final impression: Hypokalemia.\nPotassium 3.1 mmol/L (low)."}


def test_quotes_must_appear_on_cited_page():
    out = validate.verify_evidence(PAGES, [
        {"page": 1, "quote": "potassium  3.1 mmol/L", "supports": "tested"},
        {"page": 1, "quote": "Potassium 2.0 mmol/L", "supports": "tested"},
        {"page": 2, "quote": "Final impression", "supports": "provider_statement"},
    ])
    assert [e["verified"] for e in out] == [True, False, False]


def test_ontology_gaps():
    req = {"require_all": ["provider_statement"], "require_any": ["tested", "treated"]}
    ok = [{"supports": "provider_statement", "verified": True}, {"supports": "tested", "verified": True}]
    assert validate.ontology_gaps(req, ok) == []
    unverified = [{"supports": "provider_statement", "verified": False}, {"supports": "tested", "verified": True}]
    assert validate.ontology_gaps(req, unverified) == ["provider_statement"]


def test_buckets():
    assert validate.decide_bucket("claim", True, []) == "confirmed"
    assert validate.decide_bucket("claim", False, []) == "unsupported"
    assert validate.decide_bucket("claim", True, [{"type": "ontology_gap"}]) == "needs_review"
    assert validate.decide_bucket("lead", False, []) is None
    assert validate.decide_bucket("lead", True, []) == "missed"


def test_code_family_and_phi_tripwire():
    assert episodic.code_family("I21.4", "ICD-10-CM") == "I21"
    assert episodic.code_family("93010", "CPT") == "93010"
    episodic.phi_tripwire("history only, not addressed")
    with pytest.raises(ValueError):
        episodic.phi_tripwire("MRN 12345678")
