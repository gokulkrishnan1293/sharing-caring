import json
import os
from pathlib import Path

import pytest

from claire_agent.agent.graph import Deps
from claire_agent.config import Settings
from claire_agent.db import Database
from claire_agent.demo import sample_responder
from claire_agent.memory import procedural
from claire_agent.memory.procedural import SkillRegistry
from claire_agent.models import CaseIn
from claire_agent.seed import seed
from claire_agent.testing import ScriptedChatModel

ROOT = Path(__file__).resolve().parents[1]
SAMPLE = ROOT / "data" / "sample"


@pytest.fixture()
def deps():
    url = os.environ.get("TEST_DATABASE_URL")
    if not url:
        pytest.skip("set TEST_DATABASE_URL to a throwaway Postgres database")
    db = Database(url)
    db.execute("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
    db.migrate()
    seed(db, SAMPLE)
    registry = SkillRegistry.load(ROOT / "skills")
    procedural.sync_registry(db, registry)
    settings = Settings(database_url=url, skills_dir=ROOT / "skills", drift_flag_threshold=2)
    yield Deps(db=db, model=ScriptedChatModel(responder=sample_responder), registry=registry, settings=settings)
    db.close()


@pytest.fixture()
def sample_case() -> CaseIn:
    return CaseIn(**json.loads((SAMPLE / "er_case.json").read_text()))
