from fastapi.testclient import TestClient

from claire_agent.agent.graph import run_case
from claire_agent.api import create_app
from claire_agent.memory import episodic, working
from claire_agent.trace import case_stats


def test_sample_case_end_to_end(deps, sample_case):
    working.create_case(deps.db, sample_case)
    findings = {f["code"]: f for f in run_case(deps, sample_case.case_id)["findings"]}

    assert findings["I21.4"]["bucket"] == "unsupported"
    assert findings["E11.65"]["bucket"] == "confirmed"
    assert findings["93010"]["bucket"] == "confirmed"
    assert findings["71046"]["bucket"] == "confirmed"
    assert findings["R07.9"]["bucket"] == "missed"
    assert findings["E87.6"]["bucket"] == "missed"
    assert "99284" not in findings          # visit-level code is out of scope
    assert "I10" not in findings            # history-only lead is dropped
    assert all(e["verified"] for f in findings.values() for e in f["evidence"])
    pair_flags = [fl for fl in findings["E11.65"]["flags"] if fl["type"] == "pair_edit"]
    assert pair_flags == []                 # E11.9 is not reported, so no conflict

    stats = case_stats(deps.db, deps.settings, sample_case.case_id)
    assert stats["pages_opened"] < stats["pages"]
    assert stats["model_calls"] > 0 and stats["tool_calls"] > 0
    assert working.get_case(deps.db, sample_case.case_id)["status"] == "awaiting_review"


def test_rejection_becomes_precedent_and_flags_skill(deps, sample_case):
    working.create_case(deps.db, sample_case)
    run_case(deps, sample_case.case_id)
    app = create_app(deps)
    with TestClient(app) as client:
        findings = client.get(f"/cases/{sample_case.case_id}/findings").json()
        target = next(f for f in findings if f["code"] == "71046")
        body = {"decision": "reject", "coder_id": "coder-7", "reason": "insufficient_documentation",
                "root_cause": "skill_gap", "note": "views not documented clearly"}
        res = client.post(f"/findings/{target['finding_id']}/review", json=body)
        assert res.status_code == 200, res.text
        assert res.json()["drift"]["drift_flag_count"] == 1

        assert client.post(f"/findings/{target['finding_id']}/review", json=body).status_code == 422

        prec = client.get("/precedents", params={"payer": "Payer A", "code": "71046", "code_system": "CPT"}).json()
        assert prec and prec[0]["decision"] == "rejected"

        phi = {**body, "note": "DOB 01/02/1960"}
        other = next(f for f in findings if f["code"] == "93010")
        assert client.post(f"/findings/{other['finding_id']}/review", json=phi).status_code == 422

        added = client.post(f"/cases/{sample_case.case_id}/missed-codes",
                            json={"code": "I10", "code_system": "ICD-10-CM", "coder_id": "coder-7"})
        assert added.status_code == 201
        assert len(client.get("/episodes").json()) == 2
        assert client.get("/stats").json()["cases"] == 1


def test_precedent_reaches_the_agent(deps, sample_case):
    episodic.save_episode(deps.db, setting="ER", payer="Payer A", code="I21.4", code_system="ICD-10-CM",
                          decision="rejected", reason="uncertain_diagnosis", coder_id="c1", case_id="old")
    working.create_case(deps.db, sample_case)
    run_case(deps, sample_case.case_id)
    acs = next(f for f in working.list_findings(deps.db, sample_case.case_id) if f["code"] == "I21.4")
    assert acs["precedent_ids"], "the I21 precedent should be recorded on the finding"
